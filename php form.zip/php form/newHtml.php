<html>
    <head>
        <title>Michael Fergusoon BOOK form</title>
    </head>
    <body>

            <?php

            //connect to mysql databasem
            //useing id and pass
            $db_Server = mysql_connect('localhost','mikef','13897837','mikef_RYO');
            
                if (!$db_Server)
                die("unable to connect to mysql".mysql_error());
                //select BOOKS database
                if (!mysql_select_db('mikef_RYO'))
            
                    die("unable to connect to database".mysql_error());
            
                 
                    //get values 
                    $bookid = $_GET['BookID'];
                    $Genre = $_GET['Genre'];
                    $ShelveRowNumber = $_GET['ShelveRowNumber'];
                    $shelveSectionNumber = $_GET['shelveSectionNumber'];
                    $PageLength = $_GET['PageLength'];
                    $bookName = $_GET['bookName'];
                    $author = $_GET['author'];
                        
                        $sql = "INSERT INTO BOOKS('BookID', 'Genre', 'PageLength', 'Author','bookName' )
                        VALUES('$bookid','$Genre',' $PageLength',' $author','$bookName'),
                        INSERT INTO SHELVEROW(BookID,ShelveRowNumber)
                        VALUES('$bookid','$ShelveRowNumber'),
                        INSERT INTO shelveSection(ShelveRowNumber,shelveSectionNumber)
                        values('$ShelveRowNumber','$shelveSectionNumber')";
            
            
            
                
                    //execute sql
                    $insert
                    $result = mysql_query($sql);
                    if (!$result)
                    die ("unable to submit sql statment ".mysqlerror() );
            
                    //close conn
                    mysql_close($db_Server);
            
                            
                    
            ?>
        
<h1>Enter book into database</h1>
        <form method="POST">
           BookID <input name="BookID" type="text"/>
           <br/>
            genre <input name="Genre" type="text"/>
            <br/>
            Shelve Row Number<input name="ShelveRowNumber" type="text"/>
            <br/>
            
            shelve Section Number<input name="shelveSectionNumber" type="text"/>
            <br/>
            Page Length<input name="PageLength" type="text"/>
            <br/>
            book name<input name="bookName" type="text"/>
            <br/>
            author<input name="author" type="text"/>
            <br/>
            <br>
		<input type="submit" name="submit">
		<input type="Reset" name="Reset">
        </form>
    </body>
</html>