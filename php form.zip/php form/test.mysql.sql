CREATE TABLE BOOKS(
    BookID int (10) NOT NULL,
Genre char(15) NOT NULL,
PageLength int(10) NOT NULL,
Author char(20) NOT NULL,
ShelveRowNumber int (10) NOT NULL,
bookName char(50)NULL,
shelveSectionNumber int(10) NOT NULL,
CONSTRAINT BookID_PK PRIMARY KEY(BookID)
);

CREATE table SHELVEROW(
 BookID int (10) NOT NULL,
ShelveRowNumber int(10)Not NULL,
CONSTRAINT ShelveRowNumber_pk PRIMARY KEY(ShelveRowNumber),
CONSTRAINT ShelvesRow_FK FOREIGN KEY(BookID)
REFERENCES BOOKS(BookID)
);
CREATE TABLE shelveSection(
ShelveRowNumber int(10)Not NULL,
shelveSectionNumber int(10) NOT NULL,
CONSTRAINT ShelveSection_pk PRIMARY KEY(shelveSectionNumber),
CONSTRAINT ShelvesSec_FK FOREIGN KEY(ShelveRowNumber)
REFERENCES SHELVEROW(ShelveRowNumber)

);

INSERT INTO BOOKS(BookID, Genre, PageLength, Author,ShelveRowNumber,bookName,shelveSectionNumber )
VALUES('1','Horror','150','Willams','1','How to run the streets','2');
SELECT *
FROM BOOKS
--This file creates tables that I think work  